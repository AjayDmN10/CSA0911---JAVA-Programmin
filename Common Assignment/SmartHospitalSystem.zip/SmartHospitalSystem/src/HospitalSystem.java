import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class HospitalSystem {

    // =========================================================
    // CO2 - COLLECTION FRAMEWORK
    // =========================================================

    private ArrayList<Patient> patients;
    private ArrayList<Doctor> doctors;
    private ArrayList<Appointment> appointments;

    private HashMap<Integer, Patient> patientMap;
    private HashMap<Integer, Medicine> medicines;

    private HashSet<String> bookedSlots;

    private Hashtable<Integer, Doctor> doctorTable;

    private Inventory inventory;

    // =========================================================
    // CO3 - NOTIFICATION QUEUE
    // =========================================================

    private LinkedList<Notification> notificationQueue;

    private boolean notificationSystemRunning;

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public HospitalSystem() {

        patients = new ArrayList<Patient>();
        doctors = new ArrayList<Doctor>();
        appointments = new ArrayList<Appointment>();

        patientMap = new HashMap<Integer, Patient>();
        medicines = new HashMap<Integer, Medicine>();

        bookedSlots = new HashSet<String>();

        doctorTable = new Hashtable<Integer, Doctor>();

        inventory = new Inventory();

        notificationQueue =
                new LinkedList<Notification>();

        notificationSystemRunning = true;
    }

    // =========================================================
    // PATIENT MANAGEMENT
    // =========================================================

    public synchronized void addPatient(
            Patient patient
    )
            throws InvalidInputException {

        if (patient == null) {

            throw new InvalidInputException(
                    "Patient cannot be null."
            );
        }

        if (patient.getPatientId() <= 0) {

            throw new InvalidInputException(
                    "Patient ID must be greater than zero."
            );
        }

        if (patientMap.containsKey(
                patient.getPatientId())) {

            throw new InvalidInputException(
                    "Patient ID already exists."
            );
        }

        patients.add(patient);

        patientMap.put(
                patient.getPatientId(),
                patient
        );

        System.out.println(
                "Patient added successfully."
        );
    }

    public Patient searchPatient(
            int patientId
    )
            throws InvalidPatientIdException {

        Patient patient =
                patientMap.get(patientId);

        if (patient == null) {

            throw new InvalidPatientIdException(
                    "Patient ID "
                            + patientId
                            + " not found."
            );
        }

        return patient;
    }

    public void displayPatients() {

        System.out.println();
        System.out.println(
                "========== PATIENT LIST =========="
        );

        if (patients.isEmpty()) {

            System.out.println(
                    "No patients available."
            );

            return;
        }

        // CO2 - Iterator
        Iterator<Patient> iterator =
                patients.iterator();

        while (iterator.hasNext()) {

            Patient patient =
                    iterator.next();

            patient.displayPatient();

            System.out.println(
                    "----------------------------------"
            );
        }
    }

    // =========================================================
    // CO4 - PATIENT REPORT FOR AWT GUI
    // =========================================================

    public String getPatientReport() {

        StringBuilder report =
                new StringBuilder();

        report.append(
                "========== PATIENT LIST ==========\n"
        );

        if (patients.isEmpty()) {

            report.append(
                    "No patients available."
            );

            return report.toString();
        }

        Iterator<Patient> iterator =
                patients.iterator();

        while (iterator.hasNext()) {

            Patient patient =
                    iterator.next();

            report.append(
                    "Patient ID: "
                            + patient.getPatientId()
                            + "\n"
            );

            report.append(
                    "Name: "
                            + patient.getName()
                            + "\n"
            );

            report.append(
                    "Age: "
                            + patient.getAge()
                            + "\n"
            );

            report.append(
                    "Phone: "
                            + patient.getPhoneNumber()
                            + "\n"
            );

            report.append(
                    "Type: "
                            + patient.getPatientType()
                            + "\n"
            );

            report.append(
                    "----------------------------------\n"
            );
        }

        return report.toString();
    }

    // =========================================================
    // DOCTOR MANAGEMENT
    // =========================================================

    public synchronized void addDoctor(
            Doctor doctor
    )
            throws InvalidInputException {

        if (doctor == null) {

            throw new InvalidInputException(
                    "Doctor cannot be null."
            );
        }

        if (doctor.getDoctorId() <= 0) {

            throw new InvalidInputException(
                    "Doctor ID must be greater than zero."
            );
        }

        if (doctorTable.containsKey(
                doctor.getDoctorId())) {

            throw new InvalidInputException(
                    "Doctor ID already exists."
            );
        }

        doctors.add(doctor);

        doctorTable.put(
                doctor.getDoctorId(),
                doctor
        );

        System.out.println(
                "Doctor added successfully."
        );
    }

    public Doctor searchDoctor(
            int doctorId
    )
            throws InvalidDoctorIdException {

        Doctor doctor =
                doctorTable.get(doctorId);

        if (doctor == null) {

            throw new InvalidDoctorIdException(
                    "Doctor ID "
                            + doctorId
                            + " not found."
            );
        }

        return doctor;
    }

    public void displayDoctors() {

        System.out.println();
        System.out.println(
                "========== DOCTOR LIST =========="
        );

        if (doctors.isEmpty()) {

            System.out.println(
                    "No doctors available."
            );

            return;
        }

        for (Doctor doctor : doctors) {

            doctor.displayDoctor();

            System.out.println(
                    "----------------------------------"
            );
        }
    }

    // =========================================================
    // CO4 - DOCTOR REPORT FOR AWT GUI
    // =========================================================

    public String getDoctorReport() {

        StringBuilder report =
                new StringBuilder();

        report.append(
                "========== DOCTOR LIST ==========\n"
        );

        if (doctors.isEmpty()) {

            report.append(
                    "No doctors available."
            );

            return report.toString();
        }

        for (Doctor doctor : doctors) {

            report.append(
                    "Doctor ID: "
                            + doctor.getDoctorId()
                            + "\n"
            );

            report.append(
                    "Name: "
                            + doctor.getName()
                            + "\n"
            );

            report.append(
                    "Specialization: "
                            + doctor.getSpecialization()
                            + "\n"
            );

            report.append(
                    "Available Slot: "
                            + doctor.getAvailableSlot()
                            + "\n"
            );

            report.append(
                    "----------------------------------\n"
            );
        }

        return report.toString();
    }

    // =========================================================
    // APPOINTMENT MANAGEMENT
    // =========================================================

    // CO3 - synchronized method
    // Prevents multiple threads from modifying
    // appointment data at the same time.

    public synchronized void bookAppointment(
            Appointment appointment
    )
            throws InvalidPatientIdException,
            InvalidDoctorIdException,
            DuplicateAppointmentException,
            InvalidInputException {

        if (appointment == null) {

            throw new InvalidInputException(
                    "Appointment cannot be null."
            );
        }

        if (appointment.getAppointmentId() <= 0) {

            throw new InvalidInputException(
                    "Appointment ID must be greater than zero."
            );
        }

        // Validate patient
        searchPatient(
                appointment.getPatientId()
        );

        // Validate doctor
        searchDoctor(
                appointment.getDoctorId()
        );

        // Check duplicate appointment ID
        for (Appointment existing :
                appointments) {

            if (existing.getAppointmentId()
                    == appointment.getAppointmentId()) {

                throw new DuplicateAppointmentException(
                        "Appointment ID already exists."
                );
            }
        }

        String slotKey =
                appointment.getDoctorId()
                        + "-"
                        + appointment.getAppointmentDate()
                        + "-"
                        + appointment.getAppointmentTime();

        // HashSet prevents duplicate doctor slots
        if (bookedSlots.contains(slotKey)) {

            throw new DuplicateAppointmentException(
                    "Doctor appointment slot is already booked."
            );
        }

        // Shared appointment data updated safely
        appointments.add(appointment);

        bookedSlots.add(slotKey);

        System.out.println();
        System.out.println(
                "Appointment booked successfully."
        );

        // CO3 - send notification to shared queue
        addNotification(
                new Notification(
                        "Appointment "
                                + appointment.getAppointmentId()
                                + " booked for Patient "
                                + appointment.getPatientId()
                )
        );
    }

    public synchronized void cancelAppointment(
            int appointmentId
    )
            throws InvalidInputException {

        for (Appointment appointment :
                appointments) {

            if (appointment.getAppointmentId()
                    == appointmentId) {

                appointment.cancelAppointment();

                String slotKey =
                        appointment.getDoctorId()
                                + "-"
                                + appointment.getAppointmentDate()
                                + "-"
                                + appointment.getAppointmentTime();

                bookedSlots.remove(slotKey);

                System.out.println(
                        "Appointment cancelled successfully."
                );

                addNotification(
                        new Notification(
                                "Appointment "
                                        + appointmentId
                                        + " has been cancelled."
                        )
                );

                return;
            }
        }

        throw new InvalidInputException(
                "Appointment ID not found."
        );
    }

    public void displayAppointments() {

        System.out.println();
        System.out.println(
                "========== APPOINTMENT LIST =========="
        );

        if (appointments.isEmpty()) {

            System.out.println(
                    "No appointments available."
            );

            return;
        }

        for (Appointment appointment :
                appointments) {

            appointment.displayAppointment();

            System.out.println(
                    "--------------------------------------"
            );
        }
    }

    // =========================================================
    // CO4 - APPOINTMENT REPORT FOR AWT GUI
    // =========================================================

    public String getAppointmentReport() {

        StringBuilder report =
                new StringBuilder();

        report.append(
                "======= APPOINTMENT LIST =======\n"
        );

        if (appointments.isEmpty()) {

            report.append(
                    "No appointments available."
            );

            return report.toString();
        }

        for (Appointment appointment :
                appointments) {

            report.append(
                    "Appointment ID: "
                            + appointment
                            .getAppointmentId()
                            + "\n"
            );

            report.append(
                    "Patient ID: "
                            + appointment
                            .getPatientId()
                            + "\n"
            );

            report.append(
                    "Doctor ID: "
                            + appointment
                            .getDoctorId()
                            + "\n"
            );

            report.append(
                    "Date: "
                            + appointment
                            .getAppointmentDate()
                            + "\n"
            );

            report.append(
                    "Time: "
                            + appointment
                            .getAppointmentTime()
                            + "\n"
            );

            report.append(
                    "Status: "
                            + appointment.getStatus()
                            + "\n"
            );

            report.append(
                    "----------------------------------\n"
            );
        }

        return report.toString();
    }

    // =========================================================
    // PHARMACY INVENTORY
    // =========================================================

    public synchronized void addMedicine(
            Medicine medicine
    )
            throws InvalidInputException {

        if (medicine == null) {

            throw new InvalidInputException(
                    "Medicine cannot be null."
            );
        }

        if (medicine.getMedicineId() <= 0) {

            throw new InvalidInputException(
                    "Medicine ID must be greater than zero."
            );
        }

        if (medicine.getPrice() < 0) {

            throw new InvalidInputException(
                    "Medicine price cannot be negative."
            );
        }

        if (medicine.getStock() < 0) {

            throw new InvalidInputException(
                    "Medicine stock cannot be negative."
            );
        }

        if (medicines.containsKey(
                medicine.getMedicineId())) {

            throw new InvalidInputException(
                    "Medicine ID already exists."
            );
        }

        medicines.put(
                medicine.getMedicineId(),
                medicine
        );

        System.out.println(
                "Medicine added successfully."
        );
    }

    public Medicine searchMedicine(
            int medicineId
    ) {

        return medicines.get(medicineId);
    }

    // CO3 - synchronized shared inventory update

    public synchronized void updateMedicineStock(
            int medicineId,
            int quantity
    )
            throws InvalidInputException {

        Medicine medicine =
                searchMedicine(medicineId);

        if (medicine == null) {

            throw new InvalidInputException(
                    "Medicine ID not found."
            );
        }

        inventory.addStock(
                medicine,
                quantity
        );

        System.out.println(
                "Medicine stock updated successfully."
        );

        if (inventory.isLowStock(medicine)) {

            addNotification(
                    new Notification(
                            "LOW STOCK ALERT: "
                                    + medicine.getMedicineName()
                                    + " has only "
                                    + medicine.getStock()
                                    + " units."
                    )
            );
        }
    }

    // CO3 - synchronized shared inventory update

    public synchronized void sellMedicine(
            int medicineId,
            int quantity
    )
            throws InvalidInputException,
            OutOfStockException {

        Medicine medicine =
                searchMedicine(medicineId);

        if (medicine == null) {

            throw new InvalidInputException(
                    "Medicine ID not found."
            );
        }

        inventory.reduceStock(
                medicine,
                quantity
        );

        System.out.println(
                "Medicine issued successfully."
        );

        System.out.println(
                "Remaining Stock: "
                        + medicine.getStock()
        );

        if (inventory.isLowStock(medicine)) {

            addNotification(
                    new Notification(
                            "LOW STOCK ALERT: "
                                    + medicine.getMedicineName()
                                    + " has only "
                                    + medicine.getStock()
                                    + " units remaining."
                    )
            );
        }
    }

    public void displayMedicines() {

        System.out.println();
        System.out.println(
                "========== PHARMACY INVENTORY =========="
        );

        if (medicines.isEmpty()) {

            System.out.println(
                    "No medicines available."
            );

            return;
        }

        // HashMap values -> ArrayList
        ArrayList<Medicine> medicineList =
                new ArrayList<Medicine>(
                        medicines.values()
                );

        // CO2 - ListIterator
        ListIterator<Medicine> iterator =
                medicineList.listIterator();

        while (iterator.hasNext()) {

            Medicine medicine =
                    iterator.next();

            medicine.displayMedicine();

            if (inventory.isLowStock(medicine)) {

                System.out.println(
                        "ALERT: LOW STOCK"
                );
            }

            System.out.println(
                    "--------------------------------------"
            );
        }
    }

    // =========================================================
    // CO4 - MEDICINE REPORT FOR AWT GUI
    // =========================================================

    public String getMedicineReport() {

        StringBuilder report =
                new StringBuilder();

        report.append(
                "======= PHARMACY INVENTORY =======\n"
        );

        if (medicines.isEmpty()) {

            report.append(
                    "No medicines available."
            );

            return report.toString();
        }

        ArrayList<Medicine> medicineList =
                new ArrayList<Medicine>(
                        medicines.values()
                );

        ListIterator<Medicine> iterator =
                medicineList.listIterator();

        while (iterator.hasNext()) {

            Medicine medicine =
                    iterator.next();

            report.append(
                    "Medicine ID: "
                            + medicine.getMedicineId()
                            + "\n"
            );

            report.append(
                    "Name: "
                            + medicine.getMedicineName()
                            + "\n"
            );

            report.append(
                    "Type: "
                            + medicine.getMedicineType()
                            + "\n"
            );

            report.append(
                    "Price: "
                            + medicine.getPrice()
                            + "\n"
            );

            report.append(
                    "Stock: "
                            + medicine.getStock()
                            + "\n"
            );

            if (inventory.isLowStock(medicine)) {

                report.append(
                        "ALERT: LOW STOCK\n"
                );
            }

            report.append(
                    "----------------------------------\n"
            );
        }

        return report.toString();
    }

    // =========================================================
    // CO3 - NOTIFICATION QUEUE
    // =========================================================

    /*
     * Adds a notification to the shared queue.
     *
     * synchronized:
     * Ensures safe access to the shared queue.
     *
     * notifyAll():
     * Wakes the waiting NotificationThread.
     */

    public synchronized void addNotification(
            Notification notification
    ) {

        if (notification == null) {

            return;
        }

        notificationQueue.add(
                notification
        );

        notifyAll();
    }

    /*
     * Gets the next notification.
     *
     * wait():
     * NotificationThread waits when there are
     * no notifications.
     */

    public synchronized Notification
    getNextNotification() {

        while (
                notificationQueue.isEmpty()
                        && notificationSystemRunning
        ) {

            try {

                wait();

            } catch (InterruptedException e) {

                Thread.currentThread()
                        .interrupt();

                return null;
            }
        }

        if (
                notificationQueue.isEmpty()
                        && !notificationSystemRunning
        ) {

            return null;
        }

        return notificationQueue.removeFirst();
    }

    /*
     * Stops the notification thread safely.
     */

    public synchronized void
    shutdownNotifications() {

        notificationSystemRunning = false;

        notifyAll();
    }
}