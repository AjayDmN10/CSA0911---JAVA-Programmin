public class EmergencyPatient extends Patient {

    private int priorityLevel;

    public EmergencyPatient(
            int patientId,
            String name,
            int age,
            String phoneNumber,
            int priorityLevel) {

        super(patientId, name, age, phoneNumber);
        this.priorityLevel = priorityLevel;
    }

    public int getPriorityLevel() {
        return priorityLevel;
    }

    public void setPriorityLevel(int priorityLevel) {
        this.priorityLevel = priorityLevel;
    }

    @Override
    public String getPatientType() {
        return "Emergency";
    }
}