import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileManager {

    private static final String TEXT_FILE_NAME =
            "hospital_data.txt";

    private static final String SERIAL_FILE_NAME =
            "hospital_data.ser";

    /*
     * CO5 - Character Stream File Handling
     *
     * Uses:
     * FileWriter
     * BufferedWriter
     * FileReader
     * BufferedReader
     */

    public void saveData(HospitalSystem hospital) {

        try {

            BufferedWriter writer =
                    new BufferedWriter(
                            new FileWriter(TEXT_FILE_NAME)
                    );

            writer.write(
                    "=========================================="
            );
            writer.newLine();

            writer.write(
                    "       SMART HOSPITAL SYSTEM DATA"
            );
            writer.newLine();

            writer.write(
                    "=========================================="
            );
            writer.newLine();
            writer.newLine();

            writer.write("PATIENT REPORT");
            writer.newLine();

            writer.write(
                    "------------------------------------------"
            );
            writer.newLine();

            writer.write(
                    hospital.getPatientReport()
            );

            writer.newLine();
            writer.newLine();

            writer.write("DOCTOR REPORT");
            writer.newLine();

            writer.write(
                    "------------------------------------------"
            );
            writer.newLine();

            writer.write(
                    hospital.getDoctorReport()
            );

            writer.newLine();
            writer.newLine();

            writer.write("APPOINTMENT REPORT");
            writer.newLine();

            writer.write(
                    "------------------------------------------"
            );
            writer.newLine();

            writer.write(
                    hospital.getAppointmentReport()
            );

            writer.newLine();
            writer.newLine();

            writer.write("MEDICINE / INVENTORY REPORT");
            writer.newLine();

            writer.write(
                    "------------------------------------------"
            );
            writer.newLine();

            writer.write(
                    hospital.getMedicineReport()
            );

            writer.newLine();

            writer.close();

            System.out.println();
            System.out.println(
                    "Hospital data saved successfully."
            );

            System.out.println(
                    "File: " + TEXT_FILE_NAME
            );

        } catch (IOException e) {

            System.out.println(
                    "File saving error: "
                            + e.getMessage()
            );
        }
    }

    public void loadData() {

        try {

            BufferedReader reader =
                    new BufferedReader(
                            new FileReader(TEXT_FILE_NAME)
                    );

            String line;

            System.out.println();
            System.out.println(
                    "=========================================="
            );

            System.out.println(
                    "       SAVED HOSPITAL DATA"
            );

            System.out.println(
                    "=========================================="
            );

            while ((line = reader.readLine()) != null) {

                System.out.println(line);
            }

            reader.close();

        } catch (IOException e) {

            System.out.println();
            System.out.println(
                    "File loading error: "
                            + e.getMessage()
            );
        }
    }

    /*
     * CO5 - Serialization using Byte Streams
     *
     * The hospital reports are converted into
     * a serializable String array and stored
     * using ObjectOutputStream.
     */

    public void serializeData(HospitalSystem hospital) {

        String[] hospitalData = new String[4];

        hospitalData[0] =
                hospital.getPatientReport();

        hospitalData[1] =
                hospital.getDoctorReport();

        hospitalData[2] =
                hospital.getAppointmentReport();

        hospitalData[3] =
                hospital.getMedicineReport();

        try {

            FileOutputStream fileOutputStream =
                    new FileOutputStream(
                            SERIAL_FILE_NAME
                    );

            ObjectOutputStream objectOutputStream =
                    new ObjectOutputStream(
                            fileOutputStream
                    );

            objectOutputStream.writeObject(
                    hospitalData
            );

            objectOutputStream.close();
            fileOutputStream.close();

            System.out.println();
            System.out.println(
                    "Hospital data serialized successfully."
            );

            System.out.println(
                    "File: " + SERIAL_FILE_NAME
            );

        } catch (IOException e) {

            System.out.println();
            System.out.println(
                    "Serialization error: "
                            + e.getMessage()
            );
        }
    }

    /*
     * CO5 - Deserialization using Byte Streams
     */

    public void loadSerializedData() {

        try {

            FileInputStream fileInputStream =
                    new FileInputStream(
                            SERIAL_FILE_NAME
                    );

            ObjectInputStream objectInputStream =
                    new ObjectInputStream(
                            fileInputStream
                    );

            String[] hospitalData =
                    (String[]) objectInputStream.readObject();

            objectInputStream.close();
            fileInputStream.close();

            System.out.println();
            System.out.println(
                    "=========================================="
            );

            System.out.println(
                    "       DESERIALIZED HOSPITAL DATA"
            );

            System.out.println(
                    "=========================================="
            );

            System.out.println();

            System.out.println("PATIENT REPORT");
            System.out.println(
                    "------------------------------------------"
            );
            System.out.println(
                    hospitalData[0]
            );

            System.out.println();

            System.out.println("DOCTOR REPORT");
            System.out.println(
                    "------------------------------------------"
            );
            System.out.println(
                    hospitalData[1]
            );

            System.out.println();

            System.out.println("APPOINTMENT REPORT");
            System.out.println(
                    "------------------------------------------"
            );
            System.out.println(
                    hospitalData[2]
            );

            System.out.println();

            System.out.println("MEDICINE / INVENTORY REPORT");
            System.out.println(
                    "------------------------------------------"
            );
            System.out.println(
                    hospitalData[3]
            );

        } catch (IOException e) {

            System.out.println();
            System.out.println(
                    "Deserialization error: "
                            + e.getMessage()
            );

        } catch (ClassNotFoundException e) {

            System.out.println();
            System.out.println(
                    "Serialized data type error: "
                            + e.getMessage()
            );
        }
    }
}