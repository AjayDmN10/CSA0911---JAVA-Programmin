public abstract class Medicine {

    private int medicineId;
    private String medicineName;
    private double price;
    private int stock;

    public Medicine(
            int medicineId,
            String medicineName,
            double price,
            int stock) {

        this.medicineId = medicineId;
        this.medicineName = medicineName;
        this.price = price;
        this.stock = stock;
    }

    public int getMedicineId() {
        return medicineId;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public abstract String getMedicineType();

    public void displayMedicine() {
        System.out.println(
                medicineId + "\t" +
                        medicineName + "\t" +
                        getMedicineType() + "\t" +
                        price + "\t" +
                        stock
        );
    }
}