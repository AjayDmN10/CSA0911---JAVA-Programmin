public class TabletMedicine extends Medicine {

    public TabletMedicine(
            int medicineId,
            String medicineName,
            double price,
            int stock) {

        super(medicineId, medicineName, price, stock);
    }

    @Override
    public String getMedicineType() {
        return "Tablet";
    }
}