import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        HospitalSystem hospital =
                new HospitalSystem();

        FileManager fileManager =
                new FileManager();

        // CO3 - Start background notification thread
        NotificationThread notificationThread =
                new NotificationThread(hospital);

        notificationThread.setPriority(
                Thread.MIN_PRIORITY
        );

        notificationThread.start();

        int choice = -1;

        do {

            System.out.println();
            System.out.println("==========================================");
            System.out.println("       SMART HOSPITAL SYSTEM");
            System.out.println("==========================================");
            System.out.println("1. Add Patient");
            System.out.println("2. View Patients");
            System.out.println("3. Search Patient");
            System.out.println("4. Add Doctor");
            System.out.println("5. View Doctors");
            System.out.println("6. Search Doctor");
            System.out.println("7. Book Appointment");
            System.out.println("8. Cancel Appointment");
            System.out.println("9. View Appointments");
            System.out.println("10. Add Medicine");
            System.out.println("11. View Medicines");
            System.out.println("12. Update Medicine Stock");
            System.out.println("13. Issue Medicine");
            System.out.println("14. Test Concurrent Booking");
            System.out.println("15. Open AWT GUI");
            System.out.println("16. Save Data to File");
            System.out.println("17. Load Data from File");
            System.out.println("18. Serialize Hospital Data");
            System.out.println("19. Load Serialized Data");
            System.out.println("20. Generate SHA-256 Hash");
            System.out.println("0. Exit");
            System.out.println("==========================================");

            System.out.print("Enter your choice: ");

            try {

                choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {

                    case 1:

                        System.out.print("Enter Patient ID: ");
                        int patientId = scanner.nextInt();
                        scanner.nextLine();

                        System.out.print("Enter Patient Name: ");
                        String patientName = scanner.nextLine();

                        System.out.print("Enter Age: ");
                        int age = scanner.nextInt();
                        scanner.nextLine();

                        System.out.print("Enter Phone Number: ");
                        String phone = scanner.nextLine();

                        System.out.println();
                        System.out.println("1. Regular Patient");
                        System.out.println("2. Emergency Patient");

                        System.out.print("Select Patient Type: ");
                        int patientType = scanner.nextInt();

                        if (patientType == 1) {

                            hospital.addPatient(
                                    new RegularPatient(
                                            patientId,
                                            patientName,
                                            age,
                                            phone
                                    )
                            );

                        } else if (patientType == 2) {

                            System.out.print(
                                    "Enter Emergency Priority Level (1-5): "
                            );

                            int priority = scanner.nextInt();

                            hospital.addPatient(
                                    new EmergencyPatient(
                                            patientId,
                                            patientName,
                                            age,
                                            phone,
                                            priority
                                    )
                            );

                        } else {

                            throw new InvalidInputException(
                                    "Invalid patient type."
                            );
                        }

                        break;

                    case 2:

                        hospital.displayPatients();

                        break;

                    case 3:

                        System.out.print(
                                "Enter Patient ID to Search: "
                        );

                        int searchPatientId =
                                scanner.nextInt();

                        Patient patient =
                                hospital.searchPatient(
                                        searchPatientId
                                );

                        System.out.println();
                        System.out.println(
                                "Patient found successfully:"
                        );

                        patient.displayPatient();

                        break;

                    case 4:

                        System.out.print("Enter Doctor ID: ");
                        int doctorId = scanner.nextInt();
                        scanner.nextLine();

                        System.out.print("Enter Doctor Name: ");
                        String doctorName = scanner.nextLine();

                        System.out.print(
                                "Enter Specialization: "
                        );

                        String specialization =
                                scanner.nextLine();

                        System.out.print(
                                "Enter Available Slot: "
                        );

                        String slot =
                                scanner.nextLine();

                        hospital.addDoctor(
                                new Doctor(
                                        doctorId,
                                        doctorName,
                                        specialization,
                                        slot
                                )
                        );

                        break;

                    case 5:

                        hospital.displayDoctors();

                        break;

                    case 6:

                        System.out.print(
                                "Enter Doctor ID to Search: "
                        );

                        int searchDoctorId =
                                scanner.nextInt();

                        Doctor doctor =
                                hospital.searchDoctor(
                                        searchDoctorId
                                );

                        System.out.println();
                        System.out.println(
                                "Doctor found successfully:"
                        );

                        doctor.displayDoctor();

                        break;

                    case 7:

                        System.out.print(
                                "Enter Appointment ID: "
                        );

                        int appointmentId =
                                scanner.nextInt();

                        System.out.print(
                                "Enter Patient ID: "
                        );

                        int appointmentPatientId =
                                scanner.nextInt();

                        System.out.print(
                                "Enter Doctor ID: "
                        );

                        int appointmentDoctorId =
                                scanner.nextInt();

                        scanner.nextLine();

                        System.out.print(
                                "Enter Appointment Date (DD-MM-YYYY): "
                        );

                        String appointmentDate =
                                scanner.nextLine();

                        System.out.print(
                                "Enter Appointment Time: "
                        );

                        String appointmentTime =
                                scanner.nextLine();

                        Appointment appointment =
                                new Appointment(
                                        appointmentId,
                                        appointmentPatientId,
                                        appointmentDoctorId,
                                        appointmentDate,
                                        appointmentTime
                                );

                        hospital.bookAppointment(
                                appointment
                        );

                        break;

                    case 8:

                        System.out.print(
                                "Enter Appointment ID to Cancel: "
                        );

                        int cancelId =
                                scanner.nextInt();

                        hospital.cancelAppointment(
                                cancelId
                        );

                        break;

                    case 9:

                        hospital.displayAppointments();

                        break;

                    case 10:

                        System.out.print(
                                "Enter Medicine ID: "
                        );

                        int medicineId =
                                scanner.nextInt();

                        scanner.nextLine();

                        System.out.print(
                                "Enter Medicine Name: "
                        );

                        String medicineName =
                                scanner.nextLine();

                        System.out.print(
                                "Enter Price: "
                        );

                        double price =
                                scanner.nextDouble();

                        System.out.print(
                                "Enter Stock Quantity: "
                        );

                        int stock =
                                scanner.nextInt();

                        System.out.println();
                        System.out.println("1. Tablet");
                        System.out.println("2. Liquid");

                        System.out.print(
                                "Select Medicine Type: "
                        );

                        int medicineType =
                                scanner.nextInt();

                        if (medicineType == 1) {

                            hospital.addMedicine(
                                    new TabletMedicine(
                                            medicineId,
                                            medicineName,
                                            price,
                                            stock
                                    )
                            );

                        } else if (medicineType == 2) {

                            hospital.addMedicine(
                                    new LiquidMedicine(
                                            medicineId,
                                            medicineName,
                                            price,
                                            stock
                                    )
                            );

                        } else {

                            throw new InvalidInputException(
                                    "Invalid medicine type."
                            );
                        }

                        break;

                    case 11:

                        hospital.displayMedicines();

                        break;

                    case 12:

                        System.out.print(
                                "Enter Medicine ID: "
                        );

                        int updateMedicineId =
                                scanner.nextInt();

                        System.out.print(
                                "Enter Quantity to Add: "
                        );

                        int quantity =
                                scanner.nextInt();

                        hospital.updateMedicineStock(
                                updateMedicineId,
                                quantity
                        );

                        break;

                    case 13:

                        System.out.print(
                                "Enter Medicine ID: "
                        );

                        int sellMedicineId =
                                scanner.nextInt();

                        System.out.print(
                                "Enter Quantity: "
                        );

                        int sellQuantity =
                                scanner.nextInt();

                        hospital.sellMedicine(
                                sellMedicineId,
                                sellQuantity
                        );

                        break;

                    case 14:

                        System.out.print(
                                "Enter Appointment ID 1: "
                        );

                        int concurrentId1 =
                                scanner.nextInt();

                        System.out.print(
                                "Enter Appointment ID 2: "
                        );

                        int concurrentId2 =
                                scanner.nextInt();

                        System.out.print(
                                "Enter Existing Patient ID: "
                        );

                        int concurrentPatientId =
                                scanner.nextInt();

                        System.out.print(
                                "Enter Existing Doctor ID: "
                        );

                        int concurrentDoctorId =
                                scanner.nextInt();

                        scanner.nextLine();

                        System.out.print(
                                "Enter Appointment Date: "
                        );

                        String concurrentDate =
                                scanner.nextLine();

                        System.out.print(
                                "Enter Appointment Time: "
                        );

                        String concurrentTime =
                                scanner.nextLine();

                        Appointment appointment1 =
                                new Appointment(
                                        concurrentId1,
                                        concurrentPatientId,
                                        concurrentDoctorId,
                                        concurrentDate,
                                        concurrentTime
                                );

                        Appointment appointment2 =
                                new Appointment(
                                        concurrentId2,
                                        concurrentPatientId,
                                        concurrentDoctorId,
                                        concurrentDate,
                                        concurrentTime
                                );

                        BookingThread thread1 =
                                new BookingThread(
                                        hospital,
                                        appointment1
                                );

                        BookingThread thread2 =
                                new BookingThread(
                                        hospital,
                                        appointment2
                                );

                        thread1.setName(
                                "Booking-Thread-1"
                        );

                        thread2.setName(
                                "Booking-Thread-2"
                        );

                        thread1.setPriority(
                                Thread.MAX_PRIORITY
                        );

                        thread2.setPriority(
                                Thread.MAX_PRIORITY
                        );

                        System.out.println();
                        System.out.println(
                                "Starting two booking threads..."
                        );

                        thread1.start();
                        thread2.start();

                        try {

                            thread1.join();
                            thread2.join();

                        } catch (InterruptedException e) {

                            Thread.currentThread()
                                    .interrupt();

                            System.out.println(
                                    "Main thread interrupted."
                            );
                        }

                        System.out.println();
                        System.out.println(
                                "Concurrent booking test completed."
                        );

                        break;

                    case 15:

                        System.out.println();
                        System.out.println(
                                "Opening Smart Hospital Modern Swing GUI..."
                        );

                        new ModernHospitalGUI(hospital, fileManager);

                        break;

                    case 16:

                        /*
                         * CO5 - Character Stream File Handling
                         */

                        fileManager.saveData(hospital);

                        break;

                    case 17:

                        /*
                         * CO5 - Character Stream File Reading
                         */

                        fileManager.loadData();

                        break;

                    case 18:

                        /*
                         * CO5 - Serialization
                         */

                        fileManager.serializeData(hospital);

                        break;

                    case 19:

                        /*
                         * CO5 - Deserialization
                         */

                        fileManager.loadSerializedData();

                        break;

                    case 20:

                        /*
                         * CO5 - SHA-256 Hashing
                         */

                        System.out.print(
                                "Enter text to generate SHA-256 hash: "
                        );

                        String text =
                                scanner.nextLine();

                        try {

                            String hash =
                                    HashUtil.generateSHA256(
                                            text
                                    );

                            System.out.println();
                            System.out.println(
                                    "SHA-256 Hash:"
                            );

                            System.out.println(hash);

                        } catch (
                                NoSuchAlgorithmException e
                        ) {

                            System.out.println(
                                    "Hashing error: "
                                            + e.getMessage()
                            );
                        }

                        break;

                    case 0:

                        System.out.println();
                        System.out.println(
                                "Stopping notification thread..."
                        );

                        hospital.shutdownNotifications();

                        try {

                            notificationThread.join();

                        } catch (InterruptedException e) {

                            Thread.currentThread()
                                    .interrupt();
                        }

                        System.out.println(
                                "Thank you for using "
                                        + "Smart Hospital System."
                        );

                        break;

                    default:

                        System.out.println(
                                "Invalid choice. "
                                        + "Please select a valid option."
                        );
                }

            } catch (InvalidPatientIdException e) {

                System.out.println(
                        "ERROR: " + e.getMessage()
                );

            } catch (InvalidDoctorIdException e) {

                System.out.println(
                        "ERROR: " + e.getMessage()
                );

            } catch (DuplicateAppointmentException e) {

                System.out.println(
                        "ERROR: " + e.getMessage()
                );

            } catch (OutOfStockException e) {

                System.out.println(
                        "ERROR: " + e.getMessage()
                );

            } catch (InvalidInputException e) {

                System.out.println(
                        "ERROR: " + e.getMessage()
                );

            } catch (java.util.InputMismatchException e) {

                System.out.println(
                        "ERROR: Please enter the correct type of value."
                );

                scanner.nextLine();

                choice = -1;
            }

        } while (choice != 0);

        scanner.close();
    }
}