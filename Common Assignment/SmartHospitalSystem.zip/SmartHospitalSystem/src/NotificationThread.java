public class NotificationThread extends Thread {

    private HospitalSystem hospital;

    public NotificationThread(HospitalSystem hospital) {
        this.hospital = hospital;
    }

    @Override
    public void run() {

        System.out.println(
                "Notification Thread started."
        );

        System.out.println(
                "Thread Priority: "
                        + Thread.currentThread().getPriority()
        );

        while (true) {

            Notification notification =
                    hospital.getNextNotification();

            if (notification == null) {
                break;
            }

            notification.send();
        }

        System.out.println(
                "Notification Thread stopped."
        );
    }
}