public class LiquidMedicine extends Medicine {

    public LiquidMedicine(
            int medicineId,
            String medicineName,
            double price,
            int stock) {

        super(medicineId, medicineName, price, stock);
    }

    @Override
    public String getMedicineType() {
        return "Liquid";
    }
}