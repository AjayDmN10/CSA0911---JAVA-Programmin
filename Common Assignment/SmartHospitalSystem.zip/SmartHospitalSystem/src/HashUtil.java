import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashUtil {

    /*
     * CO5 - SHA-256 Hashing
     */

    public static String generateSHA256(String text)
            throws NoSuchAlgorithmException {

        MessageDigest messageDigest =
                MessageDigest.getInstance("SHA-256");

        byte[] hashBytes =
                messageDigest.digest(
                        text.getBytes(StandardCharsets.UTF_8)
                );

        StringBuilder hash =
                new StringBuilder();

        for (byte b : hashBytes) {

            hash.append(
                    String.format("%02x", b)
            );
        }

        return hash.toString();
    }
}