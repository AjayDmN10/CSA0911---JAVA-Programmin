public class Appointment {

    private int appointmentId;
    private int patientId;
    private int doctorId;
    private String appointmentDate;
    private String appointmentTime;
    private String status;

    public Appointment(
            int appointmentId,
            int patientId,
            int doctorId,
            String appointmentDate,
            String appointmentTime) {

        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.status = "Booked";
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public int getPatientId() {
        return patientId;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public String getStatus() {
        return status;
    }

    public void cancelAppointment() {
        status = "Cancelled";
    }

    public void displayAppointment() {
        System.out.println(
                appointmentId + "\t" +
                        patientId + "\t" +
                        doctorId + "\t" +
                        appointmentDate + "\t" +
                        appointmentTime + "\t" +
                        status
        );
    }
}