public class Doctor {

    private int doctorId;
    private String name;
    private String specialization;
    private String availableSlot;

    public Doctor(
            int doctorId,
            String name,
            String specialization,
            String availableSlot) {

        this.doctorId = doctorId;
        this.name = name;
        this.specialization = specialization;
        this.availableSlot = availableSlot;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public String getName() {
        return name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public String getAvailableSlot() {
        return availableSlot;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public void setAvailableSlot(String availableSlot) {
        this.availableSlot = availableSlot;
    }

    public void displayDoctor() {
        System.out.println(
                doctorId + "\t" +
                        name + "\t" +
                        specialization + "\t" +
                        availableSlot
        );
    }
}