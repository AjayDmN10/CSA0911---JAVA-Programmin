public class Inventory {

    private int lowStockLimit;

    public Inventory() {

        lowStockLimit = 5;
    }

    public int getLowStockLimit() {

        return lowStockLimit;
    }

    public void setLowStockLimit(
            int lowStockLimit) {

        this.lowStockLimit = lowStockLimit;
    }

    public boolean isLowStock(
            Medicine medicine) {

        return medicine.getStock()
                <= lowStockLimit;
    }

    public void addStock(
            Medicine medicine,
            int quantity)
            throws InvalidInputException {

        if (quantity <= 0) {

            throw new InvalidInputException(
                    "Stock quantity must be greater than zero."
            );
        }

        medicine.setStock(
                medicine.getStock()
                        + quantity
        );
    }

    public void reduceStock(
            Medicine medicine,
            int quantity)
            throws InvalidInputException,
            OutOfStockException {

        if (quantity <= 0) {

            throw new InvalidInputException(
                    "Quantity must be greater than zero."
            );
        }

        if (medicine.getStock() < quantity) {

            throw new OutOfStockException(
                    "Not enough stock available for "
                            + medicine.getMedicineName()
            );
        }

        medicine.setStock(
                medicine.getStock()
                        - quantity
        );
    }
}