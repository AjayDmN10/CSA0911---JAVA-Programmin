public class BookingThread extends Thread {

    private HospitalSystem hospital;
    private Appointment appointment;

    public BookingThread(
            HospitalSystem hospital,
            Appointment appointment
    ) {
        this.hospital = hospital;
        this.appointment = appointment;
    }

    @Override
    public void run() {

        try {

            System.out.println(
                    "Booking Thread started: "
                            + Thread.currentThread().getName()
            );

            System.out.println(
                    "Thread Priority: "
                            + Thread.currentThread().getPriority()
            );

            hospital.bookAppointment(appointment);

            System.out.println(
                    "Booking completed by "
                            + Thread.currentThread().getName()
            );

        } catch (InvalidPatientIdException e) {

            System.out.println(
                    "Booking Error: " + e.getMessage()
            );

        } catch (InvalidDoctorIdException e) {

            System.out.println(
                    "Booking Error: " + e.getMessage()
            );

        } catch (DuplicateAppointmentException e) {

            System.out.println(
                    "Booking Error: " + e.getMessage()
            );

        } catch (InvalidInputException e) {

            System.out.println(
                    "Booking Error: " + e.getMessage()
            );
        }
    }
}