import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModernHospitalGUI extends JFrame implements ActionListener {

    private HospitalSystem hospital;
    private FileManager fileManager;

    private CardLayout cardLayout;
    private JPanel contentPanel;
    private JTextArea outputArea;

    // Menu Items
    private JMenuItem dashboardMenu, patientsMenu, doctorsMenu, appointmentsMenu, pharmacyMenu, alertsMenu, reportsMenu;
    private JMenuItem dataMenu, securityMenu;

    // Form fields
    private JTextField patientIdField, patientNameField, patientAgeField, patientPhoneField, patientPriorityField;
    private JComboBox<String> patientTypeChoice;
    private JButton addPatientButton, searchPatientButton, viewPatientsButton, clearPatientButton;

    private JTextField doctorIdField, doctorNameField, specializationField, availableSlotField;
    private JButton addDoctorButton, searchDoctorButton, viewDoctorsButton, clearDoctorButton;

    private JTextField apptIdField, apptPatientIdField, apptDoctorIdField, apptDateField, apptTimeField;
    private JButton bookApptButton, cancelApptButton, viewApptsButton, concurrentApptButton, clearApptButton;

    private JTextField medIdField, medNameField, medPriceField, medStockField, medQtyField;
    private JComboBox<String> medTypeChoice;
    private JButton addMedButton, searchMedButton, updateStockButton, issueMedButton, viewMedsButton, clearMedButton;

    private JButton processNotifButton, testNotifButton;
    private JButton patReportBtn, docReportBtn, apptReportBtn, invReportBtn, compReportBtn;
    private JButton saveDataBtn, loadDataBtn, serializeBtn, loadSerializedBtn;
    private JTextField hashField;
    private JButton generateHashBtn;

    public ModernHospitalGUI(HospitalSystem hospital, FileManager fileManager) {
        this.hospital = hospital;
        this.fileManager = fileManager;

        setTitle("Smart Hospital System - Modern GUI");
        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Setup modern UI defaults
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {}

        setLayout(new BorderLayout());

        // Header
        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setBackground(Color.decode("#2C3E50"));
        JLabel title = new JLabel("SMART HOSPITAL SYSTEM", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(10, 0, 5, 0));
        
        JLabel subtitle = new JLabel("Modern JDK GUI Management Console", SwingConstants.CENTER);
        subtitle.setFont(new Font("SansSerif", Font.ITALIC, 14));
        subtitle.setForeground(Color.LIGHT_GRAY);
        subtitle.setBorder(new EmptyBorder(0, 0, 10, 0));
        
        header.add(title);
        header.add(subtitle);
        add(header, BorderLayout.NORTH);

        // Menu Bar
        setupMenus();

        // Content Area
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(Color.decode("#F4F7F6"));

        contentPanel.add(createDashboardPanel(), "DASHBOARD");
        contentPanel.add(createPatientPanel(), "PATIENTS");
        contentPanel.add(createDoctorPanel(), "DOCTORS");
        contentPanel.add(createAppointmentPanel(), "APPOINTMENTS");
        contentPanel.add(createPharmacyPanel(), "PHARMACY");
        contentPanel.add(createAlertsPanel(), "ALERTS");
        contentPanel.add(createReportsPanel(), "REPORTS");
        contentPanel.add(createDataPanel(), "DATA");
        contentPanel.add(createSecurityPanel(), "SECURITY");

        add(contentPanel, BorderLayout.CENTER);

        // Output Area
        outputArea = new JTextArea(8, 80);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        outputArea.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("System Output"));
        add(scrollPane, BorderLayout.SOUTH);

        outputArea.setText("Welcome to Smart Hospital System.\n\nUse the top menu bar to select a module.");
        cardLayout.show(contentPanel, "DASHBOARD");
        
        setVisible(true);
    }

    private void setupMenus() {
        JMenuBar mb = new JMenuBar();
        mb.setBackground(Color.decode("#ECF0F1"));
        
        JMenu navMenu = new JMenu("Modules");
        dashboardMenu = new JMenuItem("Dashboard");
        patientsMenu = new JMenuItem("Patients");
        doctorsMenu = new JMenuItem("Doctors");
        appointmentsMenu = new JMenuItem("Appointments");
        pharmacyMenu = new JMenuItem("Pharmacy");
        alertsMenu = new JMenuItem("Alerts");
        reportsMenu = new JMenuItem("Reports");
        
        JMenuItem[] navItems = {dashboardMenu, patientsMenu, doctorsMenu, appointmentsMenu, pharmacyMenu, alertsMenu, reportsMenu};
        for (JMenuItem item : navItems) {
            item.addActionListener(this);
            navMenu.add(item);
        }
        
        JMenu sysMenu = new JMenu("System");
        dataMenu = new JMenuItem("Data Management");
        securityMenu = new JMenuItem("Security / Hash");
        
        sysMenu.add(dataMenu);
        sysMenu.add(securityMenu);
        dataMenu.addActionListener(this);
        securityMenu.addActionListener(this);
        
        mb.add(navMenu);
        mb.add(sysMenu);
        setJMenuBar(mb);
    }
    
    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(Color.decode("#3498DB"));
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode("#2980B9"));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode("#3498DB"));
            }
        });
        return btn;
    }
    
    private JPanel createSectionHeader(String title) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.decode("#F4F7F6"));
        header.setBorder(new EmptyBorder(10, 10, 20, 10));
        
        JLabel lbl = new JLabel(title, SwingConstants.LEFT);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 22));
        lbl.setForeground(Color.decode("#2C3E50"));
        
        JButton backBtn = createStyledButton("← Back to Dashboard");
        backBtn.addActionListener(e -> cardLayout.show(contentPanel, "DASHBOARD"));
        
        header.add(lbl, BorderLayout.CENTER);
        header.add(backBtn, BorderLayout.EAST);
        return header;
    }

    private JPanel createDashboardPanel() {
        JPanel main = new JPanel(new BorderLayout(20, 20));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        JLabel lbl = new JLabel("DASHBOARD OVERVIEW", SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 24));
        main.add(lbl, BorderLayout.NORTH);
        
        JPanel cards = new JPanel(new GridLayout(2, 2, 20, 20));
        cards.setBackground(Color.decode("#F4F7F6"));
        
        cards.add(createDashboardCard("Patients", "Manage patient records", "PATIENTS"));
        cards.add(createDashboardCard("Doctors", "Manage doctor records", "DOCTORS"));
        cards.add(createDashboardCard("Appointments", "Book & view appointments", "APPOINTMENTS"));
        cards.add(createDashboardCard("Pharmacy", "Manage medicines & stock", "PHARMACY"));
        
        main.add(cards, BorderLayout.CENTER);
        return main;
    }
    
    private JPanel createDashboardCard(String title, String desc, String cardName) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
            new EmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel tLbl = new JLabel(title, SwingConstants.CENTER);
        tLbl.setFont(new Font("SansSerif", Font.BOLD, 20));
        tLbl.setForeground(Color.decode("#2980B9"));
        
        JLabel dLbl = new JLabel(desc, SwingConstants.CENTER);
        dLbl.setFont(new Font("SansSerif", Font.PLAIN, 14));
        
        JButton btn = createStyledButton("Open " + title);
        btn.addActionListener(e -> cardLayout.show(contentPanel, cardName));
        
        card.add(tLbl, BorderLayout.NORTH);
        card.add(dLbl, BorderLayout.CENTER);
        card.add(btn, BorderLayout.SOUTH);
        return card;
    }

    private JPanel createPatientPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("PATIENT MANAGEMENT"), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(6, 2, 10, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            new EmptyBorder(20, 20, 20, 20)
        ));

        form.add(new JLabel("Patient ID:"));
        patientIdField = new JTextField(); form.add(patientIdField);
        
        form.add(new JLabel("Patient Name:"));
        patientNameField = new JTextField(); form.add(patientNameField);
        
        form.add(new JLabel("Age:"));
        patientAgeField = new JTextField(); form.add(patientAgeField);
        
        form.add(new JLabel("Phone Number:"));
        patientPhoneField = new JTextField(); form.add(patientPhoneField);
        
        form.add(new JLabel("Patient Type:"));
        patientTypeChoice = new JComboBox<>(new String[]{"Regular", "Emergency"}); 
        form.add(patientTypeChoice);
        
        form.add(new JLabel("Emergency Priority (1-5):"));
        patientPriorityField = new JTextField("1"); form.add(patientPriorityField);
        
        main.add(form, BorderLayout.CENTER);

        JPanel btns = new JPanel(new FlowLayout());
        btns.setBackground(Color.decode("#F4F7F6"));
        addPatientButton = createStyledButton("Add Patient");
        searchPatientButton = createStyledButton("Search");
        viewPatientsButton = createStyledButton("View All");
        clearPatientButton = createStyledButton("Clear");
        
        JButton[] arr = {addPatientButton, searchPatientButton, viewPatientsButton, clearPatientButton};
        for(JButton b : arr) { b.addActionListener(this); btns.add(b); }
        main.add(btns, BorderLayout.SOUTH);
        
        return main;
    }
    
    // Quick helpers for other panels to keep script short
    private JPanel createDoctorPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("DOCTOR MANAGEMENT"), BorderLayout.NORTH);
        
        JPanel form = new JPanel(new GridLayout(4, 2, 10, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), new EmptyBorder(20, 20, 20, 20)));
        form.add(new JLabel("Doctor ID:")); doctorIdField = new JTextField(); form.add(doctorIdField);
        form.add(new JLabel("Name:")); doctorNameField = new JTextField(); form.add(doctorNameField);
        form.add(new JLabel("Specialization:")); specializationField = new JTextField(); form.add(specializationField);
        form.add(new JLabel("Available Slot:")); availableSlotField = new JTextField(); form.add(availableSlotField);
        main.add(form, BorderLayout.CENTER);
        
        JPanel btns = new JPanel(new FlowLayout());
        btns.setBackground(Color.decode("#F4F7F6"));
        addDoctorButton = createStyledButton("Add Doctor");
        searchDoctorButton = createStyledButton("Search");
        viewDoctorsButton = createStyledButton("View All");
        clearDoctorButton = createStyledButton("Clear");
        JButton[] arr = {addDoctorButton, searchDoctorButton, viewDoctorsButton, clearDoctorButton};
        for(JButton b : arr) { b.addActionListener(this); btns.add(b); }
        main.add(btns, BorderLayout.SOUTH);
        return main;
    }
    
    private JPanel createAppointmentPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("APPOINTMENTS"), BorderLayout.NORTH);
        
        JPanel form = new JPanel(new GridLayout(5, 2, 10, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), new EmptyBorder(20, 20, 20, 20)));
        form.add(new JLabel("Appt ID:")); apptIdField = new JTextField(); form.add(apptIdField);
        form.add(new JLabel("Patient ID:")); apptPatientIdField = new JTextField(); form.add(apptPatientIdField);
        form.add(new JLabel("Doctor ID:")); apptDoctorIdField = new JTextField(); form.add(apptDoctorIdField);
        form.add(new JLabel("Date:")); apptDateField = new JTextField(); form.add(apptDateField);
        form.add(new JLabel("Time:")); apptTimeField = new JTextField(); form.add(apptTimeField);
        main.add(form, BorderLayout.CENTER);
        
        JPanel btns = new JPanel(new FlowLayout());
        btns.setBackground(Color.decode("#F4F7F6"));
        bookApptButton = createStyledButton("Book Appt");
        cancelApptButton = createStyledButton("Cancel Appt");
        viewApptsButton = createStyledButton("View All");
        concurrentApptButton = createStyledButton("Test Concurrency");
        clearApptButton = createStyledButton("Clear");
        JButton[] arr = {bookApptButton, cancelApptButton, viewApptsButton, concurrentApptButton, clearApptButton};
        for(JButton b : arr) { b.addActionListener(this); btns.add(b); }
        main.add(btns, BorderLayout.SOUTH);
        return main;
    }
    
    private JPanel createPharmacyPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("PHARMACY INVENTORY"), BorderLayout.NORTH);
        
        JPanel form = new JPanel(new GridLayout(6, 2, 10, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), new EmptyBorder(20, 20, 20, 20)));
        form.add(new JLabel("Med ID:")); medIdField = new JTextField(); form.add(medIdField);
        form.add(new JLabel("Med Name:")); medNameField = new JTextField(); form.add(medNameField);
        form.add(new JLabel("Price:")); medPriceField = new JTextField(); form.add(medPriceField);
        form.add(new JLabel("Initial Stock:")); medStockField = new JTextField(); form.add(medStockField);
        form.add(new JLabel("Quantity (Issue/Update):")); medQtyField = new JTextField(); form.add(medQtyField);
        form.add(new JLabel("Type:")); medTypeChoice = new JComboBox<>(new String[]{"Tablet", "Liquid"}); form.add(medTypeChoice);
        main.add(form, BorderLayout.CENTER);
        
        JPanel btns = new JPanel(new FlowLayout());
        btns.setBackground(Color.decode("#F4F7F6"));
        addMedButton = createStyledButton("Add Med");
        searchMedButton = createStyledButton("Search");
        updateStockButton = createStyledButton("Add Stock");
        issueMedButton = createStyledButton("Issue Med");
        viewMedsButton = createStyledButton("View Inventory");
        clearMedButton = createStyledButton("Clear");
        JButton[] arr = {addMedButton, searchMedButton, updateStockButton, issueMedButton, viewMedsButton, clearMedButton};
        for(JButton b : arr) { b.addActionListener(this); btns.add(b); }
        main.add(btns, BorderLayout.SOUTH);
        return main;
    }
    
    private JPanel createAlertsPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("ALERTS & NOTIFICATIONS"), BorderLayout.NORTH);
        
        JPanel btns = new JPanel(new FlowLayout());
        btns.setBackground(Color.decode("#F4F7F6"));
        processNotifButton = createStyledButton("Process Notifications");
        testNotifButton = createStyledButton("Add Test Notification");
        JButton[] arr = {processNotifButton, testNotifButton};
        for(JButton b : arr) { b.addActionListener(this); btns.add(b); }
        main.add(btns, BorderLayout.CENTER);
        return main;
    }
    
    private JPanel createReportsPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("REPORT CENTER"), BorderLayout.NORTH);
        
        JPanel btns = new JPanel(new GridLayout(3, 2, 10, 10));
        btns.setBackground(Color.WHITE);
        btns.setBorder(new EmptyBorder(20,20,20,20));
        patReportBtn = createStyledButton("Patient Report");
        docReportBtn = createStyledButton("Doctor Report");
        apptReportBtn = createStyledButton("Appointment Report");
        invReportBtn = createStyledButton("Pharmacy Inventory Report");
        compReportBtn = createStyledButton("Complete Hospital Report");
        JButton[] arr = {patReportBtn, docReportBtn, apptReportBtn, invReportBtn, compReportBtn};
        for(JButton b : arr) { b.addActionListener(this); btns.add(b); }
        main.add(btns, BorderLayout.CENTER);
        return main;
    }
    
    private JPanel createDataPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("DATA MANAGEMENT (I/O & SERIALIZATION)"), BorderLayout.NORTH);
        
        JPanel btns = new JPanel(new GridLayout(2, 2, 20, 20));
        btns.setBackground(Color.WHITE);
        btns.setBorder(new EmptyBorder(20,20,20,20));
        saveDataBtn = createStyledButton("Save Data to TXT (Character Stream)");
        loadDataBtn = createStyledButton("Load Data from TXT (Character Stream)");
        serializeBtn = createStyledButton("Serialize Data (Byte Stream)");
        loadSerializedBtn = createStyledButton("Deserialize Data (Byte Stream)");
        JButton[] arr = {saveDataBtn, loadDataBtn, serializeBtn, loadSerializedBtn};
        for(JButton b : arr) { b.addActionListener(this); btns.add(b); }
        main.add(btns, BorderLayout.CENTER);
        return main;
    }
    
    private JPanel createSecurityPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.decode("#F4F7F6"));
        main.setBorder(new EmptyBorder(10, 20, 10, 20));
        main.add(createSectionHeader("SECURITY & HASHING"), BorderLayout.NORTH);
        
        JPanel form = new JPanel(new FlowLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(20,20,20,20));
        form.add(new JLabel("Text to Hash:"));
        hashField = new JTextField(20); form.add(hashField);
        generateHashBtn = createStyledButton("Generate SHA-256 Hash");
        generateHashBtn.addActionListener(this);
        form.add(generateHashBtn);
        main.add(form, BorderLayout.CENTER);
        return main;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        try {
            // Menu Navigation
            if(source == dashboardMenu) { cardLayout.show(contentPanel, "DASHBOARD"); }
            else if(source == patientsMenu) { cardLayout.show(contentPanel, "PATIENTS"); }
            else if(source == doctorsMenu) { cardLayout.show(contentPanel, "DOCTORS"); }
            else if(source == appointmentsMenu) { cardLayout.show(contentPanel, "APPOINTMENTS"); }
            else if(source == pharmacyMenu) { cardLayout.show(contentPanel, "PHARMACY"); }
            else if(source == alertsMenu) { cardLayout.show(contentPanel, "ALERTS"); }
            else if(source == reportsMenu) { cardLayout.show(contentPanel, "REPORTS"); }
            else if(source == dataMenu) { cardLayout.show(contentPanel, "DATA"); }
            else if(source == securityMenu) { cardLayout.show(contentPanel, "SECURITY"); }
            
            // Patient Actions
            else if(source == addPatientButton) {
                int id = Integer.parseInt(patientIdField.getText().trim());
                String name = patientNameField.getText().trim();
                int age = Integer.parseInt(patientAgeField.getText().trim());
                String phone = patientPhoneField.getText().trim();
                if(patientTypeChoice.getSelectedIndex() == 0) {
                    hospital.addPatient(new RegularPatient(id, name, age, phone));
                } else {
                    int p = Integer.parseInt(patientPriorityField.getText().trim());
                    hospital.addPatient(new EmergencyPatient(id, name, age, phone, p));
                }
                outputArea.setText("Patient Added: " + name);
            }
            else if(source == searchPatientButton) {
                int id = Integer.parseInt(patientIdField.getText().trim());
                Patient p = hospital.searchPatient(id);
                outputArea.setText("Patient Found:\nID: " + p.getPatientId() + "\nName: " + p.getName() + "\nPhone: " + p.getPhoneNumber());
            }
            else if(source == viewPatientsButton) { outputArea.setText(hospital.getPatientReport()); }
            else if(source == clearPatientButton) {
                patientIdField.setText(""); patientNameField.setText(""); patientAgeField.setText(""); patientPhoneField.setText("");
            }
            
            // Doctor Actions
            else if(source == addDoctorButton) {
                int id = Integer.parseInt(doctorIdField.getText().trim());
                String name = doctorNameField.getText().trim();
                String spec = specializationField.getText().trim();
                String slot = availableSlotField.getText().trim();
                hospital.addDoctor(new Doctor(id, name, spec, slot));
                outputArea.setText("Doctor Added: " + name);
            }
            else if(source == searchDoctorButton) {
                int id = Integer.parseInt(doctorIdField.getText().trim());
                Doctor d = hospital.searchDoctor(id);
                outputArea.setText("Doctor Found:\nName: " + d.getName() + "\nSpecialization: " + d.getSpecialization());
            }
            else if(source == viewDoctorsButton) { outputArea.setText(hospital.getDoctorReport()); }
            
            // Appt Actions
            else if(source == bookApptButton) {
                int id = Integer.parseInt(apptIdField.getText().trim());
                int pId = Integer.parseInt(apptPatientIdField.getText().trim());
                int dId = Integer.parseInt(apptDoctorIdField.getText().trim());
                String d = apptDateField.getText().trim();
                String t = apptTimeField.getText().trim();
                hospital.bookAppointment(new Appointment(id, pId, dId, d, t));
                outputArea.setText("Appointment Booked!");
            }
            else if(source == cancelApptButton) {
                int id = Integer.parseInt(apptIdField.getText().trim());
                hospital.cancelAppointment(id);
                outputArea.setText("Appointment Cancelled!");
            }
            else if(source == viewApptsButton) { outputArea.setText(hospital.getAppointmentReport()); }
            
            // Meds
            else if(source == addMedButton) {
                int id = Integer.parseInt(medIdField.getText().trim());
                String name = medNameField.getText().trim();
                double p = Double.parseDouble(medPriceField.getText().trim());
                int s = Integer.parseInt(medStockField.getText().trim());
                if(medTypeChoice.getSelectedIndex() == 0) hospital.addMedicine(new TabletMedicine(id, name, p, s));
                else hospital.addMedicine(new LiquidMedicine(id, name, p, s));
                outputArea.setText("Medicine added.");
            }
            else if(source == updateStockButton) {
                int id = Integer.parseInt(medIdField.getText().trim());
                int q = Integer.parseInt(medQtyField.getText().trim());
                hospital.updateMedicineStock(id, q);
                outputArea.setText("Stock updated.");
            }
            else if(source == issueMedButton) {
                int id = Integer.parseInt(medIdField.getText().trim());
                int q = Integer.parseInt(medQtyField.getText().trim());
                hospital.sellMedicine(id, q);
                outputArea.setText("Medicine Issued.");
            }
            else if(source == viewMedsButton) { outputArea.setText(hospital.getMedicineReport()); }
            
            // Data & Security
            else if(source == saveDataBtn) { fileManager.saveData(hospital); outputArea.setText("Data saved to TXT."); }
            else if(source == loadDataBtn) { fileManager.loadData(); outputArea.setText("Data loaded from TXT."); }
            else if(source == serializeBtn) { fileManager.serializeData(hospital); outputArea.setText("Data Serialized to .ser"); }
            else if(source == loadSerializedBtn) { fileManager.loadSerializedData(); outputArea.setText("Data loaded from .ser"); }
            else if(source == generateHashBtn) { outputArea.setText("Hash: " + HashUtil.generateSHA256(hashField.getText())); }
            
            // Reports
            else if(source == patReportBtn) { outputArea.setText(hospital.getPatientReport()); }
            else if(source == docReportBtn) { outputArea.setText(hospital.getDoctorReport()); }
            else if(source == apptReportBtn) { outputArea.setText(hospital.getAppointmentReport()); }
            else if(source == invReportBtn) { outputArea.setText(hospital.getMedicineReport()); }
            else if(source == compReportBtn) { outputArea.setText("=== COMPLETE HOSPITAL REPORT ===\\n" + hospital.getPatientReport() + "\\n" + hospital.getDoctorReport() + "\\n" + hospital.getAppointmentReport() + "\\n" + hospital.getMedicineReport()); }
            
        } catch (Exception ex) {
            outputArea.setText("ERROR: " + ex.getMessage());
        }
    }
}
