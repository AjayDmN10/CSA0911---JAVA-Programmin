public abstract class Patient {

    private int patientId;
    private String name;
    private int age;
    private String phoneNumber;

    public Patient(int patientId, String name, int age, String phoneNumber) {
        this.patientId = patientId;
        this.name = name;
        this.age = age;
        this.phoneNumber = phoneNumber;
    }

    public int getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public abstract String getPatientType();

    public void displayPatient() {
        System.out.println(
                patientId + "\t" +
                        name + "\t" +
                        age + "\t" +
                        phoneNumber + "\t" +
                        getPatientType()
        );
    }
}