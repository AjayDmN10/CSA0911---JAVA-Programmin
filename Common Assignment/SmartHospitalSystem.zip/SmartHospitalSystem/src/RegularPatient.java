public class RegularPatient extends Patient {

    public RegularPatient(int patientId, String name, int age, String phoneNumber) {
        super(patientId, name, age, phoneNumber);
    }

    @Override
    public String getPatientType() {
        return "Regular";
    }
}